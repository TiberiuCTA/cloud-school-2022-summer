package com.example.db14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Db14Application {

	public static void main(String[] args) {
		SpringApplication.run(Db14Application.class, args);
	}

}
