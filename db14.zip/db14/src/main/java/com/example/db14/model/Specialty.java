package com.example.db14.model;


public enum Specialty {
    Cardiology,
    General,
    ORL,
    Surgery
}
