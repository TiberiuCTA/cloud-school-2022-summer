package com.example.db14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Db14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
